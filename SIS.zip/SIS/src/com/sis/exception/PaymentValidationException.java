package com.sis.exception;
@SuppressWarnings("serial")
public class PaymentValidationException extends Exception {

	public PaymentValidationException(String message) {
		super(message);

}}
