package com.sis.exception;
@SuppressWarnings("serial")
public class InvalidStudentDataException extends Exception {

	public InvalidStudentDataException(String message) {
		super(message);
	}
}
