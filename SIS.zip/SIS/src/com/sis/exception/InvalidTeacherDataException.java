package com.sis.exception;
@SuppressWarnings("serial")
public class InvalidTeacherDataException extends Exception {

	public InvalidTeacherDataException(String message) {
		super(message);
	}
}
