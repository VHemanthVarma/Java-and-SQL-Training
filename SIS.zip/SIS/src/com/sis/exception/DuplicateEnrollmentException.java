package com.sis.exception;
@SuppressWarnings("serial")
public class DuplicateEnrollmentException extends Exception {

	public DuplicateEnrollmentException(String message) {
		super(message);
	}
}
