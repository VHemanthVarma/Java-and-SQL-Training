package com.sis.exception;
@SuppressWarnings("serial")
public class TeacherNotFoundException extends Exception {

	public TeacherNotFoundException(String message) {
		super(message);
	}
}
