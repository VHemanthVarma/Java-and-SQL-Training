package com.sis.entity;

public class Payment {
	private int Payment_id;
	private Student Student_id;
	private double Amount;
	private String Payment_date;
	
	public int getPayment_id() {
		return Payment_id;
	}
	public void setPayment_id(int payment_id) {
		this.Payment_id = payment_id;
	}
	public Student getStudent_id() {
		return Student_id;
	}
	public void setStudent_id(Student student_id) {
		this.Student_id = student_id;
	}
	public double getAmount() {
		return Amount;
	}
	public void setAmount(double amount) {
		this.Amount = amount;
	}
	public String getPayment_date() {
		return Payment_date;
	}
	public void setPayment_date(String payment_date) {
		this.Payment_date = payment_date;
	}
	public Payment(int payment_id, Student student_id, double amount, String payment_date) {
		this.Payment_id = payment_id;
		this.Student_id = student_id;
		this.Amount = amount;
		this.Payment_date = payment_date;
	}
	public Payment() {
		// TODO Auto-generated constructor stub
	}
	public void setStudent_id(int int1) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public String toString() {
		return "payment ID = " + Payment_id +"\n" + 
				"Amount = " + Amount +"\n" +
				"Student ID = " + Student_id +"\n" +
				"Payment Date = " + Payment_date  ;
	}
	
}
