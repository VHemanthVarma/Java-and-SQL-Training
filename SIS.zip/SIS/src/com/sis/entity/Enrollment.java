package com.sis.entity;

public class Enrollment {
	private int Enrollment_id;
	private Student Student_id;
	private Course Course_id;
	private static String Enrollment_date;
	
	public int getEnrollment_id() {
		return Enrollment_id;
	}
	public void setEnrollment_id(int enrollment_id) {
		this.Enrollment_id = enrollment_id;
	}
	public Student getStudent_id() {
		return Student_id;
	}
	public void setStudent_id(Student student_id) {
		this.Student_id = student_id;
	}
	public Course getCourse_id() {
		return Course_id;
	}
	public void setCourse_id(Course course_id) {
		this.Course_id = course_id;
	}
	public static String getEnrollment_date() {
		return Enrollment_date;
	}
	public void setEnrollment_date(String enrollment_date) {
		Enrollment.Enrollment_date = enrollment_date;
	}
	public Enrollment(int enrollment_id, Student student_id, Course course_id, String enrollment_date) {
		this.Enrollment_id = enrollment_id;
		this.Student_id = student_id;
		this.Course_id = course_id;
		Enrollment.Enrollment_date = enrollment_date;
	}
	public Enrollment() {
		// TODO Auto-generated constructor stub
	} 
	@Override
	public String toString() {
		return "Enrollment ID = " + Enrollment_id +"\n" + 
				"Course ID = " + Course_id +"\n" +
				"Student ID = " + Student_id +"\n" +
				"Enrollment Date = " + Enrollment_date +"\n" ;
	}
	
}
