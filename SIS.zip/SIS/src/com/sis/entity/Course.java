package com.sis.entity;

public class Course {

	private static int Course_id;
	private String Course_name;
	private String Course_code;
	private String Instructor_name;
	private int Credits;
	
	public static int getCourse_id() {
		return Course_id;
	}
	public void setCourse_id(int course_id) {
		Course.Course_id = course_id;
	}
	public String getCourse_name() {
		return Course_name;
	}
	public void setCourse_name(String course_name) {
		this.Course_name = course_name;
	}
	public String getCourse_code() {
		return Course_code;
	}
	public void setCourse_code(String course_code) {
		this.Course_code = course_code;
	}
	public String getInstructor_name() {
		return Instructor_name;
	}
	public void setInstructor_name(String instructor_name) {
		this.Instructor_name = instructor_name;
	}
	public Course(int course_id, String course_name, String course_code, String instructor_name) {
		Course.Course_id = course_id;
		this.Course_name = course_name;
		this.Course_code = course_code;
		this.Instructor_name = instructor_name;
	}
	public Course() {
		// TODO Auto-generated constructor stub
	}
	public Course(int courseId) {
		// TODO Auto-generated constructor stub
	}
	public int getCredits() {
		return Credits;
	}
	public void setCredits(int credits) {
		this.Credits = credits;
	}
	public void setInstructor_name(Teacher teacher) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public String toString() {
		return "Course ID = " + Course_id +"\n" + 
				"Course Name = " + Course_name +"\n" ;	
	}
}
