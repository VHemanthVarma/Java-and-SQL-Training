package com.sis.entity;

public class Teacher {
	private static int Teacher_id;
	private String First_name;
	private String Last_name;
	private String Email;
	
	public static int getTeacher_id() {
		return Teacher_id;
	}
	public void setTeacher_id(int teacher_id) {
		Teacher_id = teacher_id;
	}
	public String getFirst_name() {
		return First_name;
	}
	public void setFirst_name(String first_name) {
		this.First_name = first_name;
	}
	public String getLast_name() {
		return Last_name;
	}
	public void setLast_name(String last_name) {
		this.Last_name = last_name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		this.Email = email;
	}
	public Teacher(int teacher_id, String first_name, String last_name, String email) {
		Teacher.Teacher_id = teacher_id;
		this.First_name = first_name;
		this.Last_name = last_name;
		this.Email = email;
	}
	public Teacher() {
		// TODO Auto-generated constructor stub
	}
	public Teacher(int teacher_Id) {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "First Name = " + First_name +"\n" + 
				"Last Name = " + Last_name +"\n" +
				"Teacher ID = " + Teacher_id +"\n" +
				"Email ="+ Email + "\n" ;
	}

}
