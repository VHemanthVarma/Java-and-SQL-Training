package com.sis.entity;


public class Student {
	private static int Student_ID;
	private String First_name;
	private String Last_name;
	private String Date_of_birth;
	private String Email; 
	private String Phone_number;
	
	public int getStudent_ID() {
		return Student_ID;
	}
	public static void setStudent_ID(int student_ID) {
		Student_ID = student_ID;
	}
	public String getFirst_name() {
		return First_name;
	}
	public void setFirst_name(String first_name) {
		this.First_name = first_name;
	}
	public String getLast_name() {
		return Last_name;
	}
	public void setLast_name(String last_name) {
		this.Last_name = last_name;
	}
	public String getDate_of_birth() {
		return Date_of_birth;
	}
	public void setDate_of_birth(String date) {
		this.Date_of_birth = date;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		this.Email = email;
	}
	public String getPhone_number() {
		return Phone_number;
	}
	public void setPhone_number(String phone_number) {
		this.Phone_number = phone_number;
	}
	public Student( int student_ID, String first_name, String last_name, String date_of_birth, String email,
			String phone_number) {
		Student_ID = student_ID;
		this.First_name = first_name;
		this.Last_name = last_name;
		this.Date_of_birth = date_of_birth;
		this.Email = email;
		this.Phone_number = phone_number;
	}
	public Student(int studentId) {
		// TODO Auto-generated constructor stub
	}
	public Student() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "First Name = " + First_name +"\n" + 
				"Last Name = " + Last_name +"\n" +
				"Student ID = " + Student_ID +"\n" +
				"Date of Birth = " + Date_of_birth + "\n" +
				"Email ="+ Email + "\n" +
				"Phone Number = " + Phone_number ;
	}
}
