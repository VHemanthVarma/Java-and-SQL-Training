package com.sis.dao;

import java.util.List;

import com.sis.entity.Course;
import com.sis.entity.Payment;
import com.sis.entity.Student;

public interface StudentService  {
	 void updateStudentInfo(Student student, String firstName, String lastName, String
			 dateOfBirth, String email, String phoneNumber);
	 void makePayment(Student student, double amount);
	 void displayStudentInfo(int student_id);
	 List<Course> getEnrolledCourses(int student_id);
	 List<Payment> getPaymentHistory(int studentid);
	 boolean enrollInCourse(int studentId, int courseId );
	}
