package com.sis.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.sis.entity.Course;
import com.sis.entity.Payment;
import com.sis.entity.Student;

public class StudentServiceImpl implements StudentService {
	private Connection conn;
	public StudentServiceImpl() {
	
	conn = com.sis.util.DBConnUtil.getConnection();
	}
	@Override
	public boolean enrollInCourse(int studentId, int courseId ) {
	  
		   String enrollQuery = "INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)";
		try (PreparedStatement preparedStatement = conn.prepareStatement(enrollQuery)) {
	        preparedStatement.setInt(1, studentId);
	        preparedStatement.setInt(2, courseId);
	        

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Student enrolled in the course successfully.");
	        } else {
	            System.out.println("Failed to enroll student in the course.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        
	    }
		return false;
	}

	@Override
	public void updateStudentInfo(Student student, String firstName, String lastName, String dateOfBirth, String email, String phoneNumber) {
	    
	    String updateQuery = "UPDATE students SET first_name=?, last_name=?, date_of_birth=?, email=?, phone_number=? WHERE student_id=?";

	    try (PreparedStatement ps = conn.prepareStatement(updateQuery)) {
	        ps.setString(1, firstName);
	        ps.setString(2, lastName);
	        ps.setString(3, dateOfBirth);
	        ps.setString(4, email);
	        ps.setString(5, phoneNumber);
	        ps.setInt(6, student.getStudent_ID());

	        int rowsAffected = ps.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Student information updated successfully.");
	           
	        } else {
	           // System.out.println("Failed to update student information.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	@Override
	public void makePayment(Student student, double amount) {

	    String insertQuery = "INSERT INTO payments (student_id, amount) VALUES (?, ?)";

	    try (PreparedStatement ps = conn.prepareStatement(insertQuery)) {
	        ps.setInt(1, student.getStudent_ID());
	        ps.setDouble(2, amount);
	     

	        int rowsAffected = ps.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Payment recorded successfully.");
	        } else {
	            System.out.println("Failed to record payment.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        
	    }
	}


	@Override
	public void displayStudentInfo(int student_id) {
		Student student=new Student();
	    String selectQuery = "SELECT * FROM students WHERE student_id = ?";

	    try (PreparedStatement ps = conn.prepareStatement(selectQuery)) {
	        ps.setInt(1, student_id);

	        ResultSet rs = ps.executeQuery();

	        if (rs.next()) {
	            System.out.println("Student Information:");
	            Student.setStudent_ID(rs.getInt("student_id"));
	            student.setFirst_name(rs.getString("first_name"));
	            student.setLast_name( rs.getString("last_name"));
	            student.setDate_of_birth(rs.getString("date_of_birth"));
	            student.setEmail(rs.getString("email"));
	            student.setPhone_number( rs.getString("phone_number"));
	            System.out.println(student);
	        } else {
	            System.out.println("Student not found.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        
	    }
	}


	@Override
	public List<Course> getEnrolledCourses(int student_id) {
		 Course course = new Course();
	    List<Course> enrolledCourses = new ArrayList<>();
	    String selectQuery = "SELECT c.* FROM enrollments e " +
	                        "JOIN courses c ON e.course_id = c.course_id " +
	                        "WHERE e.student_id = ?";

	    try (PreparedStatement ps = conn.prepareStatement(selectQuery)) {
	        ps.setInt(1, student_id);

	        ResultSet rs = ps.executeQuery();

	        while (rs.next()) {
	           
	            course.setCourse_id(rs.getInt("course_id"));
	            course.setCourse_name(rs.getString("course_name"));
	            course.setCredits(rs.getInt("credits"));
	            enrolledCourses.add(course);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return enrolledCourses;
	}


	@Override
	public List<Payment> getPaymentHistory(int studentid) {
		 Payment payment = new Payment();
	    List<Payment> paymentHistory = new ArrayList<>();
	    String selectQuery = "SELECT * FROM payments WHERE student_id = ?";

	    try (PreparedStatement ps = conn.prepareStatement(selectQuery)) {
	        ps.setInt(1, studentid);

	        ResultSet rs = ps.executeQuery();

	        while (rs.next()) {
	           
	            payment.setPayment_id(rs.getInt("payment_id"));
	            payment.setStudent_id(rs.getInt("student_id"));
	            payment.setAmount(rs.getDouble("amount"));
	            payment.setPayment_date(rs.getString("payment_date"));
	            paymentHistory.add(payment);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return paymentHistory;
	}
	public boolean makePayment(int studentId, double amount) {
		String insertQuery = "INSERT INTO payments (student_id, amount) VALUES (?, ?)";

	    try (PreparedStatement ps = conn.prepareStatement(insertQuery)) {
	        ps.setInt(1, studentId);
	        ps.setDouble(2, amount);
	        //ps.setInt(3, studentId);

	        int rowsAffected = ps.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Payment recorded successfully.");
	        } else {
	            System.out.println("Failed to record payment.");
	        
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	       
	    }
	    return false;
	}
	public boolean updateStudentInfo(int studentId, String newFirstName, String newLastName, String newDateOfBirth,
			String newEmail, String newPhoneNumber) {
		// TODO Auto-generated method stub
		String updateQuery = "UPDATE students SET first_name=?, last_name=?, date_of_birth=?, email=?, phone_number=? WHERE student_id=?";

	    try (PreparedStatement ps = conn.prepareStatement(updateQuery)) {
	        ps.setString(1, newFirstName);
	        ps.setString(2, newLastName);
	        ps.setString(3, newDateOfBirth);
	        ps.setString(4, newEmail);
	        ps.setString(5, newPhoneNumber);
	        ps.setInt(6, studentId);

	        int rowsAffected = ps.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Student information updated successfully.");
	           
	        } else {
	            //System.out.println("Failed to update student information.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
		return false;
	}

	
}

