package com.sis.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.sis.entity.Course;
import com.sis.entity.Enrollment;
import com.sis.entity.Student;


public class EnrollmentServiceImpl implements EnrollmentService{
	private Connection conn;
	public EnrollmentServiceImpl() {
		conn = com.sis.util.DBConnUtil.getConnection();
	}

	@Override
	public Student getStudent(Enrollment enrollment) {
	    Student student = null;
	    String selectStudentQuery = "SELECT * FROM students WHERE student_id = (SELECT student_id FROM enrollments WHERE enrollment_id = ?)";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectStudentQuery)) {
	        preparedStatement.setInt(1, enrollment.getEnrollment_id());

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                // Create Student object
	                student = new Student();
	                Student.setStudent_ID(resultSet.getInt("student_id"));
	                student.setFirst_name(resultSet.getString("first_name"));
	                student.setLast_name(resultSet.getString("last_name"));
	                student.setDate_of_birth(resultSet.getString("date_of_birth"));
	                student.setEmail(resultSet.getString("email"));
	                student.setPhone_number(resultSet.getString("phone_number"));
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return student;
	}


	@Override
	public Course getCourse(Enrollment enrollment) {
	    Course course = null;
	    String selectCourseQuery = "SELECT * FROM courses WHERE course_id = (SELECT course_id FROM enrollments WHERE enrollment_id = ?)";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectCourseQuery)) {
	        preparedStatement.setInt(1, enrollment.getEnrollment_id());

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                // Create Course object
	                course = new Course();
	                course.setCourse_id(resultSet.getInt("course_id"));
	                course.setCourse_name(resultSet.getString("course_name"));
	                course.setCredits(resultSet.getInt("credits"));
	                // You may want to set other properties based on your database schema
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return course;
	}

	@Override
	public boolean enrollInCourse(Student student, Course course) {
		// TODO Auto-generated method stub
		return false;
	}


}

