package com.sis.dao;


import com.sis.entity.Course;
import com.sis.entity.Student;


public interface sis {
	 void enrollStudentInCourse(Student student, Course course);
	 void assignTeacherToCourse(int teacherid, int courseid);
	 void recordPayment(int studentid, double amount, String paymentDate);
	 void generateEnrollmentReport(int courseid);
	 void generatePaymentReport(int studentid);
	 void calculateCourseStatistics(int courseid);
	}
