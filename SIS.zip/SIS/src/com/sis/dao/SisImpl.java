package com.sis.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.sis.entity.Course;
import com.sis.entity.Payment;
import com.sis.entity.Student;
import com.sis.entity.Teacher;

public class SisImpl implements sis{
	private Connection conn;
	public SisImpl() {
		conn = com.sis.util.DBConnUtil.getConnection();
	}
	Teacher teacher = new Teacher();
	Course course = new Course();
	Student student = new Student();
	Payment payment = new Payment();
	@Override
	public void enrollStudentInCourse(Student student, Course course) {		
	   String enrollQuery = "INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)";
	   

	    try (PreparedStatement preparedStatement = conn.prepareStatement(enrollQuery)) {
	        preparedStatement.setInt(1, student.getStudent_ID());
	        preparedStatement.setInt(2, Course.getCourse_id());
	       
	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Student enrolled in the course successfully.");
	        } else {
	            System.out.println("Failed to enroll student in the course.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	@Override
	public void assignTeacherToCourse(int teacherid, int courseid) {

	    String assignTeacherQuery = "UPDATE courses SET teacher_id =? WHERE course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(assignTeacherQuery)) {
	  
	        preparedStatement.setInt(1, teacherid);
	        preparedStatement.setInt(2, courseid);

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Teacher " + teacher.getFirst_name() + " " + teacher.getLast_name() +
	                    " assigned to the course " + course.getCourse_name() + " successfully.");
	        } else {
	            System.out.println("Failed to assign teacher to the course.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	@Override
	public void recordPayment(int studentid, double amount, String paymentDate) {
		String recordPaymentQuery = "INSERT INTO payments (student_id, amount, payment_date) VALUES (?, ?, ?)";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(recordPaymentQuery)) {
	        preparedStatement.setInt(1, studentid);
	        preparedStatement.setDouble(2, amount);
	        preparedStatement.setString(3, paymentDate);

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Payment recorded successfully for student " + studentid + ". Amount: " + amount + ", Date: " +
	                    paymentDate);
	        } else {
	            System.out.println("Failed to record payment for student " + studentid);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


	@Override
	public void generateEnrollmentReport(int courseid) {
		    String enrollmentReportQuery = "SELECT students.student_id, students.first_name, students.last_name, students.email " +
	            "FROM students " +
	            "INNER JOIN enrollments ON enrollments.student_id = students.student_id " +
	            "WHERE enrollments.course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(enrollmentReportQuery)) {
	        preparedStatement.setInt(1, courseid);

	        ResultSet resultSet = preparedStatement.executeQuery();

	        System.out.println("===== Enrollment Report for Course: " + courseid + " =====");
	        
	        while (resultSet.next()) {
	            int studentID = resultSet.getInt("student_id");
	            String firstName = resultSet.getString("first_name");
	            String lastName = resultSet.getString("last_name");
	            String email = resultSet.getString("email");

	            System.out.println("Student ID: " + studentID +
	                    ", Name: " + firstName + " " + lastName +
	                    ", Email: " + email);
	        }

	        System.out.println("=============================");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


	@Override
	public void generatePaymentReport(int studentid) {
	  String paymentReportQuery = "SELECT * FROM payments WHERE student_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(paymentReportQuery)) {
	        preparedStatement.setInt(1, studentid);

	        ResultSet resultSet = preparedStatement.executeQuery();

	        System.out.println("===== Payment Report for Student: " + studentid +" =====");
	        

	        while (resultSet.next()) {
	            int paymentID = resultSet.getInt("payment_id");
	            double amount = resultSet.getDouble("amount");
	            String paymentDate = resultSet.getString("payment_date");

	            System.out.println("Payment ID: " + paymentID +
	                    ", Amount: $" + amount +
	                    ", Payment Date: " + paymentDate);
	        }

	        System.out.println("==============================");
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	@Override
	public void calculateCourseStatistics(int courseid) {
	
	    String enrollmentCountQuery = "SELECT COUNT(*) AS enrollmentCount FROM enrollments WHERE student_id = ?";
	    String totalPaymentsQuery = "SELECT SUM(amount) AS totalPayments FROM payments WHERE student_id = ?";

	    try (PreparedStatement enrollmentCountStatement = conn.prepareStatement(enrollmentCountQuery);
	         PreparedStatement totalPaymentsStatement = conn.prepareStatement(totalPaymentsQuery)) {

	        enrollmentCountStatement.setInt(1, courseid);
	        totalPaymentsStatement.setInt(1, courseid);

	        ResultSet enrollmentCountResult = enrollmentCountStatement.executeQuery();
	        ResultSet totalPaymentsResult = totalPaymentsStatement.executeQuery();

	        if (enrollmentCountResult.next() && totalPaymentsResult.next()) {
	            int enrollmentCount = enrollmentCountResult.getInt("enrollmentCount");
	            double totalPayments = totalPaymentsResult.getDouble("totalPayments");

	            System.out.println("===== Course Statistics for Course_id" + courseid + " =====");
	            System.out.println("Enrollment Count: " + enrollmentCount);
	            System.out.println("Total Payments: $" + totalPayments);
	            System.out.println("==============================");
	        } else {
	            System.out.println("Failed to retrieve course statistics.");
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


}