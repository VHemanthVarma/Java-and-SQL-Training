package com.sis.dao;

import com.sis.entity.Course;
import com.sis.entity.Enrollment;
import com.sis.entity.Student;

public interface EnrollmentService {
	 Student getStudent(Enrollment enrollment);
	 Course getCourse(Enrollment enrollment);
	boolean enrollInCourse(Student student, Course course);
	}
