package com.sis.dao;

import java.util.List;

import com.sis.entity.Course;
import com.sis.entity.Enrollment;
import com.sis.entity.Payment;
import com.sis.entity.Student;
import com.sis.entity.Teacher;

public class ServiceProviderImpl implements ServiceProvider{

	@Override
	public void updateStudentInfo(Student student, String firstName, String lastName, String dateOfBirth, String email,
			String phoneNumber) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void makePayment(Student student, double amount) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayStudentInfo(int student_id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Course> getEnrolledCourses(int student_id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Payment> getPaymentHistory(int studentid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean enrollInCourse(int studentId, int courseId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void updateTeacherInfo(int teacherId, String name, String lastName, String email) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayTeacherInfo(int teacherid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Course> getAssignedCourses(int teacherid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Student getStudent(Payment payment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getPaymentAmount(Payment payment) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String getPaymentDate(Payment payment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void assignTeacher(Course course, Teacher teacher) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCourseInfo(Course course, String courseName) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void displayCourseInfo(Course course) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Student> getEnrollments(Course course) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Teacher getTeacher(Course course) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Student getStudent(Enrollment enrollment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Course getCourse(Enrollment enrollment) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void enrollStudentInCourse(Student student, Course course) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void assignTeacherToCourse(int teacherid, int courseid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void recordPayment(int studentid, double amount, String paymentDate) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void generateEnrollmentReport(int courseid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void generatePaymentReport(int studentid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void calculateCourseStatistics(int courseid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean enrollInCourse(Student student, Course course) {
		// TODO Auto-generated method stub
		return false;
	}

	
		
	}	

