package com.sis.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.sis.entity.Payment;
import com.sis.entity.Student;

public class PaymentServiceImpl implements PaymentService {
	private Connection conn;
	public PaymentServiceImpl() {
		conn = com.sis.util.DBConnUtil.getConnection();
	}
	@Override
	public Student getStudent(Payment payment) {
		Student student = new Student();
	    String selectStudentQuery = "SELECT * FROM students WHERE student_id = (SELECT student_id FROM payments WHERE payment_id = ?)";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectStudentQuery)) {
	        preparedStatement.setInt(1, payment.getPayment_id());

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                // Create Student object
	                Student.setStudent_ID(resultSet.getInt("student_id"));
	                student.setFirst_name(resultSet.getString("first_name"));
	                student.setLast_name(resultSet.getString("last_name"));
	                // You may want to set other properties based on your database schema
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return student;
	}

	@Override
	public double getPaymentAmount(Payment payment) {
	    double paymentAmount = 0.0;
	    String selectPaymentAmountQuery = "SELECT amount FROM payments WHERE payment_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectPaymentAmountQuery)) {
	        preparedStatement.setInt(1, payment.getPayment_id());

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                // Retrieve payment amount
	                paymentAmount = resultSet.getDouble("amount");
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return paymentAmount;
	}

	@Override
	public String getPaymentDate(Payment payment) {
	    String paymentDate = null;
	    String selectPaymentDateQuery = "SELECT payment_date FROM payments WHERE payment_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectPaymentDateQuery)) {
	        preparedStatement.setInt(1, payment.getPayment_id());

	        try (ResultSet resultSet = preparedStatement.executeQuery()) {
	            if (resultSet.next()) {
	                // Retrieve payment date
	                paymentDate = resultSet.getString("payment_date");
	            }
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return paymentDate;
	}


}

