package com.sis.dao;

import java.util.List;

import com.sis.entity.Course;
import com.sis.entity.Enrollment;
import com.sis.entity.Payment;
import com.sis.entity.Student;
import com.sis.entity.Teacher;


public interface ServiceProvider extends StudentService,TeacherService,PaymentService,CourseService,EnrollmentService,sis {
	interface StudentService  {
		 void enrollInCourse(int studentId, int courseId);
		 void updateStudentInfo(int studentId, String firstName, String lastName, String dateOfBirth, String email, String phoneNumber);
		 void makePayment(Student student, double amount);
		 void displayStudentInfo(int student_id);
		 List<Course> getEnrolledCourses(int student_id);
		 List<Payment> getPaymentHistory(int studentid);
		boolean makePayment(int studentId, double amount);
		}
	interface TeacherService  {
		 void updateTeacherInfo(int teacherId, String name,String lastName, String email);
		 void displayTeacherInfo(int teacherid);
		 List<Course> getAssignedCourses(int teacherid);
		}
	interface PaymentService{
		 Student getStudent(Payment payment);
		 double getPaymentAmount(Payment payment);
		 String getPaymentDate(Payment payment);
		}
	interface CourseService {
		 void assignTeacher(Course course, Teacher teacher);
		 void updateCourseInfo(Course course, String courseName);
		 void displayCourseInfo(Course course);
		 List<Student> getEnrollments(Course course);
		 Teacher getTeacher(Course course);
		}
	interface EnrollmentService {
		 Student getStudent(Enrollment enrollment);
		 Course getCourse(Enrollment enrollment);
		}
	interface sis {
		 void enrollStudentInCourse(Student student, Course course);
		 void assignTeacherToCourse(int teacherid, int courseid);
		 void recordPayment(int studentid, double amount, String paymentDate);
		 void generateEnrollmentReport(int courseid);
		 void generatePaymentReport(int studentid);
		 void calculateCourseStatistics(int courseid);
		}
	
}

