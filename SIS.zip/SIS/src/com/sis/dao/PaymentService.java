package com.sis.dao;


import com.sis.entity.Payment;
import com.sis.entity.Student;

public interface PaymentService{
	 Student getStudent(Payment payment);
	 double getPaymentAmount(Payment payment);
	 String getPaymentDate(Payment payment);
	}
