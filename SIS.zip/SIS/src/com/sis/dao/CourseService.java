package com.sis.dao;

import java.util.List;

import com.sis.entity.Course;
import com.sis.entity.Student;
import com.sis.entity.Teacher;

public interface CourseService {
	 void assignTeacher(Course course, Teacher teacher);
	 void updateCourseInfo(Course course, String courseName);
	 void displayCourseInfo(Course course);
	 List<Student> getEnrollments(Course course);
	 Teacher getTeacher(Course course);

}
