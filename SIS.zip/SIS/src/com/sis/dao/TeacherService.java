package com.sis.dao;

import java.util.List;

import com.sis.entity.Course;


public interface TeacherService  {
	 void updateTeacherInfo(int teacherId, String name,String lastName, String email);
	 void displayTeacherInfo(int teacherid);
	 List<Course> getAssignedCourses(int teacherid);
	}

