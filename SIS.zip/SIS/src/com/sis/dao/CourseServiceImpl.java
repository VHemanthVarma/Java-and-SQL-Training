package com.sis.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.sis.entity.Course;
import com.sis.entity.Student;
import com.sis.entity.Teacher;

public class CourseServiceImpl implements CourseService {
	private Connection conn;
	public CourseServiceImpl() {
	conn = com.sis.util.DBConnUtil.getConnection();
	}

	@Override
	public void assignTeacher(Course course, Teacher teacher) {
	    String Query = "UPDATE courses SET teacher_id = ? WHERE course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(Query)) {
	        preparedStatement.setInt(1, Teacher.getTeacher_id());
	        preparedStatement.setInt(2, Course.getCourse_id());

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Teacher assigned to the course successfully.");
	        } else {
	            System.out.println("Failed to assign teacher to the course.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}

	

	@Override
	public void updateCourseInfo(Course course, String courseName) {
	    String updateCourseQuery = "UPDATE courses SET course_name = ? WHERE course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(updateCourseQuery)) {
	        preparedStatement.setString(1, courseName);
	      
	        preparedStatement.setInt(2, Course.getCourse_id());

	        int rowsAffected = preparedStatement.executeUpdate();

	        if (rowsAffected > 0) {
	            System.out.println("Course information updated successfully.");
	        } else {
	            System.out.println("Failed to update course information.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


	@Override
	public void displayCourseInfo(Course course) {
	    String selectCourseQuery = "SELECT * FROM courses WHERE course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectCourseQuery)) {
	        preparedStatement.setInt(1, Course.getCourse_id());

	        ResultSet resultSet = preparedStatement.executeQuery();

	        if (resultSet.next()) {
	            System.out.println("Course ID: " + resultSet.getInt("course_id"));
	            System.out.println("Course Name: " + resultSet.getString("course_name"));
	            System.out.println("teacher_id " + resultSet.getInt("teacher_id"));
	            // Add more fields as needed
	        } else {
	            System.out.println("Course not found.");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


	@Override
	public List<Student> getEnrollments(Course course) {
	    List<Student> enrolledStudents = new ArrayList<>();
	    String selectEnrollmentsQuery = "SELECT students.* FROM students " +
	                                    "JOIN enrollments ON students.student_id = enrollments.student_id " +
	                                    "WHERE enrollments.course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectEnrollmentsQuery)) {
	        preparedStatement.setInt(1, Course.getCourse_id());

	        ResultSet resultSet = preparedStatement.executeQuery();

	        while (resultSet.next()) {
	            Student student = new Student();
	            Student.setStudent_ID(resultSet.getInt("student_id"));
	            student.setFirst_name(resultSet.getString("first_name"));
	            student.setLast_name(resultSet.getString("last_name"));
	            student.setDate_of_birth(resultSet.getString("date_of_birth"));
	            student.setEmail(resultSet.getString("email"));
	            student.setPhone_number(resultSet.getString("phone_number"));
	            // Add more fields as needed

	            enrolledStudents.add(student);
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return enrolledStudents;
	}


	@Override
	public Teacher getTeacher(Course course) {
	    Teacher teacher = null;
	    String selectTeacherQuery = "SELECT teachers.* FROM teachers " +
	                               "JOIN courses ON teachers.teacher_id = courses.teacher_id " +
	                               "WHERE courses.course_id = ?";

	    try (PreparedStatement preparedStatement = conn.prepareStatement(selectTeacherQuery)) {
	        preparedStatement.setInt(1, Course.getCourse_id());

	        ResultSet resultSet = preparedStatement.executeQuery();

	        if (resultSet.next()) {
	            teacher = new Teacher();
	            teacher.setTeacher_id(resultSet.getInt("teacher_id"));
	            teacher.setFirst_name(resultSet.getString("first_name"));
	            teacher.setLast_name(resultSet.getString("last_name"));
	            teacher.setEmail(resultSet.getString("email"));
	            // Add more fields as needed
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return teacher;
	}


}
