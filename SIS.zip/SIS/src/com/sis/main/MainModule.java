package com.sis.main;

import java.util.List;
import java.util.Scanner;

import com.sis.dao.CourseServiceImpl;
import com.sis.dao.EnrollmentServiceImpl;
import com.sis.dao.PaymentServiceImpl;
import com.sis.dao.SisImpl;
import com.sis.dao.StudentServiceImpl;
import com.sis.dao.TeacherServiceImpl;
import com.sis.entity.Course;
import com.sis.entity.Enrollment;
import com.sis.entity.Payment;
import com.sis.entity.Student;
import com.sis.entity.Teacher;

public class MainModule {


	private static final Scanner scanner = new Scanner(System.in);
  //  private static final ServiceProvider ServiceProvider = new ServiceProviderImpl();
    private static final StudentServiceImpl StudentService = new StudentServiceImpl();
    private static final TeacherServiceImpl TeacherService = new TeacherServiceImpl();
    private static final PaymentServiceImpl PaymentService = new PaymentServiceImpl();
    private static final CourseServiceImpl CourseService = new CourseServiceImpl();
    private static final EnrollmentServiceImpl EnrollmentService =  new EnrollmentServiceImpl();
    private static final SisImpl sisImpl = new SisImpl();
    public static void main(String[] args) {
        int choice;
        do {
            displayMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    StudentService();
                    break;
                case 2:
                    TeacherService();
                    break;
                case 3:
                    PaymentService();
                    break;
                case 4:
                	CourseService();
                	break;
                case 5:
                    EnrollmentService();
                    break;
                case 6:
                    sis();
                    break;
                case 7:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 7);
    }

	private static void sis() {
		int choice;
        do {
            sisMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	enrollStudentInCourse();
                    break;
                case 2:
                	assignTeacherToCourse();
                    break;
                case 3:
                	recordPayment();
                    break;
                case 4:
                	generateEnrollmentReport();
                	break;
                case 5:
                	generatePaymentReport();
                    break;
                case 6:
                	calculateCourseStatistics();
                    break;                
                case 7:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 7);		
	}

	private static void calculateCourseStatistics() {
	    System.out.print("Enter Course ID: ");
	    int courseid = scanner.nextInt();
		sisImpl.calculateCourseStatistics(courseid);
	}


	private static void generatePaymentReport() {
	    System.out.print("Enter Student ID: ");
	    int studentid = scanner.nextInt();
	    sisImpl.generatePaymentReport(studentid);
	}


	private static void generateEnrollmentReport() {
	    System.out.print("Enter Course ID: ");
	    int courseid = scanner.nextInt();  
	    sisImpl.generateEnrollmentReport(courseid);
	}

	private static void recordPayment() {
	    System.out.print("Enter Student ID: ");
	    int studentid = scanner.nextInt();
	    System.out.print("Enter Payment Amount: ");
	    double amount = scanner.nextDouble();
	    scanner.nextLine();  // Consume the newline character
	    System.out.print("Enter Payment Date (YYYY-MM-DD): ");
	    String paymentDate = scanner.nextLine();

	    sisImpl.recordPayment(studentid, amount, paymentDate);
	}


	private static void assignTeacherToCourse() {
	    System.out.print("Enter Teacher ID: ");
	    int teacherid = scanner.nextInt();
	    System.out.print("Enter Course ID: ");
	    int courseid = scanner.nextInt();
	    scanner.nextLine();  // Consume the newline character

	    sisImpl.assignTeacherToCourse(teacherid, courseid);
	}


	private static void enrollStudentInCourse() {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();
	    System.out.print("Enter Course ID: ");
	    int courseId = scanner.nextInt();
	    scanner.nextLine();  // Consume the newline character

	    Student student = new Student();
	    Student.setStudent_ID(studentId);

	    Course course = new Course();
	    course.setCourse_id(courseId);
	    
	    sisImpl.enrollStudentInCourse(student, course);
	}


	private static void sisMenu() {
		System.out.println("===== Welcome to Student Services =====");
        System.out.println("1. Enroll Student In Course");
        System.out.println("2. Assign Teacher to Course");
        System.out.println("3. Make Payment");
        System.out.println("4. View Enrollment Information");
        System.out.println("5. View Payment Information");
        System.out.println("6. Course Statistics");
        System.out.println("7. Exit");		
	}

	private static void EnrollmentService() {
		int choice;
        do {
            EnrollmentMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	getStudent2();
                    break;
                case 2:
                	getCourse();
                    break;
                case 3:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 3);			
	}
	private static void getCourse() {
        System.out.print("Enter Enrollment ID: ");
        int enrollmentId = scanner.nextInt();
        scanner.nextLine();  // Consume the newline character

        // Create an Enrollment object with the entered Enrollment ID
        Enrollment enrollment = new Enrollment();
        enrollment.setEnrollment_id(enrollmentId);

        // Call the getCourse method from EnrollmentServiceImpl
        Course course = EnrollmentService.getCourse(enrollment);

        // Display the result
        if (course != null) {
            System.out.println("Course Information:");
            System.out.println("Course ID: " + Course.getCourse_id());
            System.out.println("Course Name: " + course.getCourse_name());
            System.out.println("Credits: " + course.getCredits());
            // Display other course information as needed
        } else {
            System.out.println("Course not found.");
        }
    }

	 private static void getStudent2() {
	        System.out.print("Enter Enrollment ID: ");
	        int enrollmentId = scanner.nextInt();
	        scanner.nextLine();  // Consume the newline character

	        Enrollment enrollment = new Enrollment();
	        enrollment.setEnrollment_id(enrollmentId);	       

	        // Call the getStudent method from EnrollmentServiceImpl
	        Student student = EnrollmentService.getStudent(enrollment);

	        // Display the result
	        if (student != null) {
	            System.out.println("Student Information:");
	            System.out.println("Student ID: " + student.getStudent_ID());
	            System.out.println("First Name: " + student.getFirst_name());
	            System.out.println("Last Name: " + student.getLast_name());
	            System.out.println("Date of Birth: " + student.getDate_of_birth());
	            System.out.println("Email: " + student.getEmail());
	            System.out.println("Phone Number: " + student.getPhone_number());
	            // Display other student information as needed
	        } else {
	            System.out.println("Student not found.");
	        }
	    }

	private static void EnrollmentMenu() {
		System.out.println("===== Welcome to Enrollment Services =====");
        System.out.println("1. View Assigned Student");
        System.out.println("2. View Assigned Course");
        System.out.println("3. Exit");		
	}

	private static void CourseService() {
		int choice;
        do {
            CourseMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	assignTeacher();
                    break;
                case 2:
                	updateCourseInfo();
                    break;
                case 3:
                	displayCourseInfo();
                    break;
                case 4:
                	getEnrollments();
                	break;
                case 5:
                	getTeacher();
                    break;
                case 6:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 6);		
	}

	private static void getTeacher() {
	    System.out.print("Enter Course ID: ");
	    int courseId = scanner.nextInt();
	    scanner.nextLine();  // Consume the newline character

	    Course course = new Course();
	    course.setCourse_id(courseId);

	    
	    Teacher teacher = CourseService.getTeacher(course);

	    if (teacher != null) {
	        System.out.println("===== Teacher Information for Course ID " + courseId + " =====");
	        System.out.println("Teacher ID: " + Teacher.getTeacher_id());
	        System.out.println("First Name: " + teacher.getFirst_name());
	        System.out.println("Last Name: " + teacher.getLast_name());
	        System.out.println("Email: " + teacher.getEmail());
	        // Add more fields as needed
	        System.out.println("==============================");
	    } else {
	        System.out.println("No teacher found for Course ID " + courseId);
	    }
	}

	private static void getEnrollments() {
	    System.out.print("Enter Course ID: ");
	    int courseId = scanner.nextInt();
	    scanner.nextLine();  // Consume the newline character

	    Course course = new Course();
	    course.setCourse_id(courseId);

	    List<Student> enrolledStudents = CourseService.getEnrollments(course);

	    if (!enrolledStudents.isEmpty()) {
	        System.out.println("===== Enrollments for Course ID " + courseId + " =====");
	        for (Student student : enrolledStudents) {
	            System.out.println("Student ID: " + student.getStudent_ID());
	            System.out.println("First Name: " + student.getFirst_name());
	            System.out.println("Last Name: " + student.getLast_name());
	            System.out.println("Date of Birth: " + student.getDate_of_birth());
	            System.out.println("Email: " + student.getEmail());
	            System.out.println("Phone Number: " + student.getPhone_number());
	            // Add more fields as needed
	            System.out.println("==============================");
	        }
	    } else {
	        System.out.println("No enrollments found for Course ID " + courseId);
	    }
	}



	private static void displayCourseInfo() {
	    System.out.print("Enter Course ID: ");
	    int courseId = scanner.nextInt();
	    scanner.nextLine();  // Consume the newline character

	    Course course = new Course();
	    course.setCourse_id(courseId);
	    CourseService.displayCourseInfo(course);
	}


	private static void updateCourseInfo() {
	   

	    System.out.print("Enter Course ID: ");
	    int courseId = scanner.nextInt();
	    scanner.nextLine();  // Consume the newline character

	    System.out.print("Enter new Course Name: ");
	    String courseName = scanner.nextLine();

	    

	    Course course = new Course();
	    course.setCourse_id(courseId);

	    CourseService.updateCourseInfo(course, courseName);
	}


	private static void assignTeacher() {
	    

	    System.out.print("Enter Course ID: ");
	    int courseId = scanner.nextInt();
	    scanner.nextLine();  // Consume the newline character

	    System.out.print("Enter Teacher ID: ");
	    int teacherId = scanner.nextInt();
	    scanner.nextLine();  // Consume the newline character

	    Course course = new Course();
	    course.setCourse_id(courseId);

	    Teacher teacher = new Teacher();
	    teacher.setTeacher_id(teacherId);

	    CourseService.assignTeacher(course, teacher);
	    
	}


	private static void CourseMenu() {
		System.out.println("===== Welcome to Course Services =====");
        System.out.println("1. Assign Teacher");
        System.out.println("2. Update Course Information");
        System.out.println("3. View Course Information");
        System.out.println("4. View Course Enrollments");
        System.out.println("5. View Assigned Teacher");
        System.out.println("6. Exit");
		
	}

	private static void PaymentService() {
		int choice;
        do {
            PaymentsMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	getStudent();
                    break;
                case 2:
                	getPaymentAmount();
                    break;
                case 3:
                	getPaymentDate();
                    break;
                case 4:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 4);		
	}

	 private static void getPaymentDate() {
	        System.out.print("Enter Payment ID: ");
	        int paymentId = scanner.nextInt();
	        scanner.nextLine();  // Consume the newline character

	        // Create a Payment object with the entered Payment ID
	        Payment payment = new Payment();
	        payment.setPayment_id(paymentId);

	        // Call the getPaymentDate method from PaymentServiceImpl
	        String paymentDate = PaymentService.getPaymentDate(payment);

	        // Display the result
	        if (paymentDate != null) {
	            System.out.println("Payment Date: " + paymentDate);
	        } else {
	            System.out.println("Failed to retrieve payment date.");
	        }
	    }

	 private static void getPaymentAmount() {
	        System.out.print("Enter Payment ID: ");
	        int paymentId = scanner.nextInt();
	        scanner.nextLine();  // Consume the newline character

	        // Create a Payment object with the entered Payment ID
	        Payment payment = new Payment();
	        payment.setPayment_id(paymentId);

	        // Call the getPaymentAmount method from PaymentServiceImpl
	        double paymentAmount = PaymentService.getPaymentAmount(payment);

	        // Display the result
	        System.out.println("Payment Amount: $" + paymentAmount);
	    }


	    private static void getStudent() {
	        System.out.print("Enter Payment ID: ");
	        int paymentId = scanner.nextInt();
	        scanner.nextLine();  // Consume the newline character

	        // Create a Payment object with the entered Payment ID
	        Payment payment = new Payment();
	        payment.setPayment_id(paymentId);

	        // Call the getStudent method from PaymentServiceImpl
	        Student student = PaymentService.getStudent(payment);

	        // Display the result
	        if (student != null) {
	            System.out.println("Student Information:");
	            System.out.println("Student ID: " + student.getStudent_ID());
	            System.out.println("First Name: " + student.getFirst_name());
	            System.out.println("Last Name: " + student.getLast_name());
	            // Display other student information as needed
	        } else {
	            System.out.println("Student not found.");
	        }
	    }

	private static void PaymentsMenu() {
		System.out.println("===== Welcome to Payment Services =====");
        System.out.println("1. View payment Details");
        System.out.println("2. View Payment Amount");
        System.out.println("3. View Payment Date");
        System.out.println("4. Exit");			
	}

	private static void TeacherService() {
		int choice;
        do {
            TeacherMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	updateTeacherInfo();
                    break;
                case 2:
                	displayTeacherInfo();
                    break;
                case 3:
                	getAssignedCourses();
                    break;
                case 4:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 4);
		
	}

	private static void getAssignedCourses() {
	    System.out.print("Enter Teacher ID: ");
	    int teacherid = scanner.nextInt();

	   
	    List<Course> assignedCourses = TeacherService.getAssignedCourses(teacherid);

	    if (!assignedCourses.isEmpty()) {
	        System.out.println("Assigned Courses:");
	        for (Course course : assignedCourses) {
	            System.out.println("Course ID: " + Course.getCourse_id());
	            System.out.println("Course Name: " + course.getCourse_name());
	            System.out.println("Credits: " + course.getCredits());
	           
	            System.out.println("============");
	        }
	    } else {
	        System.out.println("No assigned courses found for the teacher.");
	    }
	}

	private static void displayTeacherInfo() {
	    System.out.print("Enter Teacher ID: ");
	    int teacherid = scanner.nextInt();

	 
	    TeacherService.displayTeacherInfo(teacherid);
	}

	private static void updateTeacherInfo() {
	    System.out.print("Enter Teacher ID: ");
	    int teacherId = scanner.nextInt();
	    System.out.print("Enter New First Name: ");
	    String newFirstName = scanner.next();
	    System.out.print("Enter New Last Name: ");
	    String newLastName = scanner.next();
	    System.out.print("Enter New Email: ");
	    String newEmail = scanner.next();

	    TeacherService.updateTeacherInfo(teacherId, newFirstName, newLastName, newEmail);
	}


	private static void TeacherMenu() {
		System.out.println("===== Welcome to Teacher Services =====");
        System.out.println("1. Update Teacher Information");
        System.out.println("2. View Teacher Information");
        System.out.println("3. View Assigned Courses");
        System.out.println("4. Exit");		
	}

	private static void StudentService() {
		int choice;
        do {
            StudentMenu();
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                	enrollInCourse();
                    break;
                case 2:
                	updateStudentInfo();
                    break;
                case 3:
                	makePayment();
                    break;
                case 4:
                	displayStudentInfo();
                	break;
                case 5:
                	getEnrolledCourses();
                    break;
                case 6:
                	getPaymentHistory();
                    break;
                case 7:
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }

        } while (choice != 7);
		
	}

	private static void getPaymentHistory() {
	    System.out.print("Enter Student ID: ");
	    int studentid = scanner.nextInt();
	   

	    // Call the static method on the interface to get payment history
	    List<Payment> paymentHistory = StudentService.getPaymentHistory(studentid);

	    if (paymentHistory != null && !paymentHistory.isEmpty()) {
	        System.out.println("Payment History for Student ID " + studentid + ":");
	        for (Payment payment : paymentHistory) {
	            System.out.println("Payment ID: " + payment.getPayment_id());
	            System.out.println("Amount: " + payment.getAmount());
	            System.out.println("Payment Date: " + payment.getPayment_date());
	            System.out.println("============");
	        }
	    } else {
	        System.out.println("No payment history found for the student.");
	    }
	}


	private static void getEnrolledCourses() {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();

	   

	    List<Course> enrolledCourses = StudentService.getEnrolledCourses(studentId);

	    if (enrolledCourses != null && !enrolledCourses.isEmpty()) {
	        System.out.println("Enrolled Courses:");
	        for (Course course : enrolledCourses) {
	            System.out.println(course.getCourse_name());
	        }
	    } else {
	        System.out.println("No enrolled courses found for the student.");
	    }
	}


	private static void displayStudentInfo() {

	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt(); 
	    StudentService.displayStudentInfo(studentId);
	    
	}


	private static void makePayment() {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();
	    System.out.print("Enter Payment Amount: ");
	    double amount = scanner.nextDouble();
	    scanner.nextLine();  
	
		boolean result = StudentService.makePayment(studentId, amount);
		
	    

	    if (result) {
	        System.out.println("Payment successful!");
	    } else {
	        //System.out.println("Payment failed. Please try again.");
	    }
	}



	private static void updateStudentInfo() {
	    System.out.print("Enter Student ID: ");
	    int studentId = scanner.nextInt();
	    System.out.print("Enter New First Name: ");
	    String newFirstName = scanner.next();
	    System.out.print("Enter New Last Name: ");
	    String newLastName = scanner.next();
	    System.out.print("Enter New Date of Birth (YYYY-MM-DD): ");
	    String newDateOfBirth = scanner.next();
	    System.out.print("Enter New Email: ");
	    String newEmail = scanner.next();
	    System.out.print("Enter New Phone Number: ");
	    String newPhoneNumber = scanner.next();

	    boolean result = StudentService.updateStudentInfo(studentId, newFirstName, newLastName, newDateOfBirth, newEmail, newPhoneNumber);

	    if (result) {
	        System.out.println("Student information updated successfully!");
	    } else {
	        System.out.println("Failed to update student information. Please try again.");
	    }
	}

	private static void enrollInCourse() {
	    System.out.print("Enter Student Id: ");
	    int studentId = scanner.nextInt();
	    System.out.print("Enter Course Id: ");
	    int courseId = scanner.nextInt();

	    boolean result = StudentService.enrollInCourse(studentId, courseId);

	    if (result) {
	        System.out.println("Student enrolled in the course successfully!");
	    } else {
	        System.out.println("Failed to enroll student in the course. Please try again.");
	    }
	}

	private static void StudentMenu() {
		System.out.println("===== Welcome to Student Services =====");
        System.out.println("1. Enroll A Course");
        System.out.println("2. Update Student Information");
        System.out.println("3. Make Payment");
        System.out.println("4. View Student Information");
        System.out.println("5. Enrolled Courses");
        System.out.println("6. Payment History");
        System.out.println("7. Exit");
		
	}

	private static void displayMenu() {
        System.out.println("===== Student Information System =====");
        System.out.println("1. Student Services");
        System.out.println("2. Teacher Services");
        System.out.println("3. Payment Services");
        System.out.println("4. Course Services");
        System.out.println("5. Enrollment Services");
        System.out.println("6. Quick Services");
        System.out.println("7. Exit");
	}
}
	

