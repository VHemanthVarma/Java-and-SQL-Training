package com.virtualartgallery.util;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class DBPropertyUtil {
    public static String getPropertyString() {
        Properties prop = new Properties();
        String conn = "";

        try {
            // load a properties file
            prop.load(new FileInputStream("D:\\hexa\\2nd phase\\New folder\\propertyFilePath"));

            // get the property value and build the connection string
            String host = prop.getProperty("hostname");
            String dbName = prop.getProperty("dbname");
            String user = prop.getProperty("username");
            String password = prop.getProperty("password");
            String port = prop.getProperty("port");

            conn = "jdbc:mysql://" + host + ":" + port + "/" + dbName + "?user=" + user + "&password=" + password;

        } catch (IOException ex) {
            ex.printStackTrace();
        }

        return conn;
    }
}