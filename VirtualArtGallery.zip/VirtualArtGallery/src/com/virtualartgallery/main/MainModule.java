package com.virtualartgallery.main;

import com.virtualartgallery.dao.IVirtualArtGallery;
import com.virtualartgallery.dao.IVirtualArtGalleryImplementation;
import com.virtualartgallery.entity.Artist;
import com.virtualartgallery.entity.Artwork;
import com.virtualartgallery.exception.ArtWorkNotFoundException;
import com.virtualartgallery.exception.UserNotFoundException;

import java.util.List;
import java.util.Scanner;

public class MainModule {
	
	    private final IVirtualArtGallery virtualArtGallery;

	    public MainModule(IVirtualArtGallery virtualArtGallery) {
	        this.virtualArtGallery = virtualArtGallery;
	    }

	    public static void main(String[] args) throws Exception {
	        IVirtualArtGallery virtualArtGallery = new IVirtualArtGalleryImplementation();
	        MainModule mainModule = new MainModule(virtualArtGallery);
	        mainModule.run();
	    }

	    public void run() throws Exception {
	        Scanner scanner = new Scanner(System.in);

	        while (true) {
	            System.out.println("Virtual Art Gallery Menu:");
	            System.out.println("1. Add Artwork");
	            System.out.println("2. Update Artwork");
	            System.out.println("3. Remove Artwork");
	            System.out.println("4. Get Artwork by ID");
	            System.out.println("5. Search Artworks");
	            System.out.println("6. Add artwork to favorite");
	            System.out.println("7. Remove artwork from Favorites");
	            System.out.println("8. get user favorite artwork");
	            System.out.println("9. Exit");
	            System.out.print("Enter your choice: ");

	            int choice = scanner.nextInt();
	            scanner.nextLine();  // Consume the newline character

	            switch (choice) {
	                case 1:
	                    addArtwork(scanner);
	                    break;
	                case 2:
	                    updateArtwork(scanner);
	                    break;
	                case 3:
	                    removeArtwork(scanner);
	                    break;
	                case 4:
	                    getArtworkById(scanner);
	                    break;
	                case 5:
	                    searchArtworks(scanner);
	                    break;
	                case 6:
	                	addArtworkToFavorites(scanner);
	                	break;
	                case 7:
	                	removeArtworkFromFavorites(scanner);
	                	break;
	                case 8:
	                	viewUserFavorites(scanner);
	                	break;
	                case 9:
	                    System.out.println("Exiting the Virtual Art Gallery. Goodbye!");
	                    System.exit(0);
	                    break;
	                default:
	                    System.out.println("Invalid choice. Please enter a valid option.");
	            }
	        }
	    }

	    private void addArtwork(Scanner scanner) {
	        System.out.println("Enter Artwork Details:");
	        
	       
	        System.out.print("Enter Title: ");
	        String title = scanner.nextLine();

	        System.out.print("Description: ");
	        String description = scanner.nextLine();

	        System.out.print("Creation Date: ");
	        String creationDate = scanner.nextLine();

	        System.out.print("Medium: ");
	        String medium = scanner.nextLine();

	        System.out.print("Image URL: ");
	        String imageURL = scanner.nextLine();
	        
	        System.out.println("Enter artwork ID");
	        int artworkId = scanner.nextInt();
	        

	        // Assuming you have a valid artwork ID, replace it with the actual value
	        

	        Artwork artwork = new Artwork(artworkId, title, description, creationDate, medium, imageURL);

	        if (virtualArtGallery.addArtwork(artwork)) {
	            System.out.println("Artwork added successfully!");
	        } else {
	            System.out.println("Failed to add artwork. Please try again.");
	        }
	    }

	    private void updateArtwork(Scanner scanner) throws ArtWorkNotFoundException {
	        System.out.print("Enter Artwork ID to update: ");
	        int artworkId = scanner.nextInt();
	        scanner.nextLine();  // Consume the newline character
	       
			System.out.println("Enter New Artwork Details:");

			System.out.print("Title: ");
			String title = scanner.nextLine();

			System.out.print("Description: ");
			String description = scanner.nextLine();

			System.out.print("Creation Date: ");
			String creationDate = scanner.nextLine();

			System.out.print("Medium: ");
			String medium = scanner.nextLine();

			System.out.print("Image URL: ");
			String imageURL = scanner.nextLine();

			// Assuming you have a valid artist ID, replace it with the actual value
			Artist artistId  = new Artist();

			Artwork updatedArtwork = new Artwork(artworkId, title, description, creationDate, medium, imageURL, artistId);

			if (virtualArtGallery.updateArtwork(updatedArtwork)) {
			    System.out.println("Artwork updated successfully!");
			} else {
			    System.out.println("Failed to update artwork. Please try again.");
			}
	    }

	    private void removeArtwork(Scanner scanner) throws ArtWorkNotFoundException {
	        System.out.print("Enter Artwork ID to remove: ");
	        int artworkId = scanner.nextInt();
	        scanner.nextLine();  // Consume the newline character

	        if (virtualArtGallery.removeArtwork(artworkId)) {
	            System.out.println("Artwork removed successfully!");
	        } else {
	            System.out.println("Failed to remove artwork. Please try again.");
	        }
	    }

	    private void getArtworkById(Scanner scanner) throws ArtWorkNotFoundException {
	        System.out.print("Enter Artwork ID to retrieve: ");
	        int artworkId = scanner.nextInt();
	        scanner.nextLine();  // Consume the newline character

	        Artwork artwork = virtualArtGallery.getArtworkById(artworkId);
			System.out.println("Artwork Details:");
			System.out.println(artwork.toString());
	    }

	    private void searchArtworks(Scanner scanner) throws ArtWorkNotFoundException {
	        System.out.print("Enter keyword to search artworks: ");
	        String keyword = scanner.nextLine();

	        List<Artwork> artworks = virtualArtGallery.searchArtworks(keyword);

	        if (!artworks.isEmpty()) {
	            System.out.println("Search Results:");
	            for (Artwork artwork : artworks) {
	                System.out.println(artwork);
	            }
	        } else {
	            System.out.println("No artworks found for the given keyword.");
	        }
	    }
	    
	 // Inside the MainModule class

	    private void addArtworkToFavorites(Scanner scanner)throws UserNotFoundException {
	        System.out.print("Enter User ID: ");
	        int userId = scanner.nextInt();
	        scanner.nextLine();  // Consume the newline character

	        System.out.print("Enter Artwork ID to add to favorites: ");
	        int artworkId = scanner.nextInt();
	        scanner.nextLine();  // Consume the newline character

	        try {
	            if (virtualArtGallery.addArtworkToFavorite(userId, artworkId)) {
	                System.out.println("Artwork added to favorites successfully!");
	            } else {
	                System.out.println("Failed to add artwork to favorites. Please try again.");
	            }
	           	}
	        finally
	        {
	        	
	        }
	    }

	    private void removeArtworkFromFavorites(Scanner scanner)throws UserNotFoundException {
	        System.out.print("Enter User ID: ");
	        int userId = scanner.nextInt();
	        scanner.nextLine();  // Consume the newline character

	        System.out.print("Enter Artwork ID to remove from favorites: ");
	        int artworkId = scanner.nextInt();
	        scanner.nextLine();  // Consume the newline character

	        try {
	            if (virtualArtGallery.removeArtworkFromFavorite(userId, artworkId)) {
	                System.out.println("Artwork removed from favorites successfully!");
	            } else {
	                System.out.println("Failed to remove artwork from favorites. Please try again.");
	            }
	        } finally {
	        	
	        }
	    }
	   
	        private void viewUserFavorites(Scanner scanner) throws UserNotFoundException {
	            System.out.print("Enter User ID: ");
	            int userId = scanner.nextInt();
	            scanner.nextLine();  // Consume the newline character

	            try {
	                List<Artwork> userFavorites = virtualArtGallery.getUserFavoriteArtworks(userId);

	                if (!userFavorites.isEmpty()) {
	                    System.out.println("User Favorites:");
	                    for (Artwork artwork : userFavorites) {
	                        System.out.println(artwork);
	                    }
	                } else {
	                    System.out.println("User has no favorite artworks.");
	                }
	            } finally
	            {
	            	
	            }
	        }
	    }