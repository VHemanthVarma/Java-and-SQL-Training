package com.virtualartgallery.dao;


import java.util.List;

import com.virtualartgallery.entity.Artist;
import com.virtualartgallery.entity.Artwork;
import com.virtualartgallery.entity.Gallery;
import com.virtualartgallery.entity.User;
import com.virtualartgallery.exception.ArtWorkNotFoundException;
import com.virtualartgallery.exception.UserNotFoundException;

public interface IVirtualArtGallery {

    // Artwork Management
    boolean addArtwork(Artwork artwork);
    boolean updateArtwork(Artwork artwork) throws ArtWorkNotFoundException;
    boolean removeArtwork(int artworkId) throws ArtWorkNotFoundException;
    Artwork getArtworkById(int artworkId) throws ArtWorkNotFoundException;
    List<Artwork> searchArtworks(String keyword) throws ArtWorkNotFoundException;

    // User Favorites
    boolean addArtworkToFavorite(int userId, int artworkId);
    boolean removeArtworkFromFavorite(int userId, int artworkId)throws UserNotFoundException;
    List<Artwork> getUserFavoriteArtworks(int userId);

    // Other methods for managing artists, galleries, and users (if needed)
    boolean addArtist(Artist artist);
    boolean updateArtist(Artist artist);
    boolean removeArtist(int artistId);
    Artist getArtistById(int artistId);
    
    boolean addGallery(Gallery gallery);
    boolean updateGallery(Gallery gallery);
    boolean removeGallery(int galleryId);
    Gallery getGalleryById(int galleryId);

    boolean addUser(User user);
    boolean updateUser(User user);
    boolean removeUser(int userId);
    User getUserById(int userId);
}
