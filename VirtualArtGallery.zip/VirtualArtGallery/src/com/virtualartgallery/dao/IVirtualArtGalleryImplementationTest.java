package com.virtualartgallery.dao;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.util.List;

import org.junit.Test;

import com.virtualartgallery.entity.Artist;
import com.virtualartgallery.entity.Artwork;
import com.virtualartgallery.entity.Gallery;
import com.virtualartgallery.exception.ArtWorkNotFoundException;
import com.virtualartgallery.exception.GalleryNotFoundException;

public class IVirtualArtGalleryImplementationTest {
	 IVirtualArtGallery virtualArtGallery = new IVirtualArtGalleryImplementation();

	 @Test
	    public void testAddArtwork() throws ArtWorkNotFoundException {
	        // Create a sample Artwork object for testing
			Artwork artwork = new Artwork(1, "Test Title", "Test Description",
			        "2022-01-21", "Oil Painting", "test_image_url");

			// Call the addArtwork method
			boolean isAdded = virtualArtGallery.addArtwork(artwork);

			// Check if the artwork was added successfully
			assertTrue(isAdded);

			// Optional: Check if the added artwork is present in the database
			Artwork retrievedArtwork = virtualArtGallery.getArtworkById(1);
			assertNotNull(retrievedArtwork);
			assertEquals(artwork.getTitle(), retrievedArtwork.getTitle());
	   }

	 @Test
	    public void testUpdateArtwork() throws ArtWorkNotFoundException {
	        // Add a sample artwork for testing
			Artwork originalArtwork = new Artwork(1, "Original Title", "Original Description",
			        "2022-01-21", "Oil Painting", "original_image_url");
			virtualArtGallery.addArtwork(originalArtwork);

			// Create an updated version of the artwork
			Artwork updatedArtwork = new Artwork(1, "Updated Title", "Updated Description",
			        "2022-01-22", "Watercolor Painting", "updated_image_url");

			// Call the updateArtwork method
			boolean isUpdated = virtualArtGallery.updateArtwork(updatedArtwork);

			// Check if the artwork was updated successfully
			assertTrue(isUpdated);

			// Optional: Check if the updated artwork details match the database
			Artwork retrievedArtwork = virtualArtGallery.getArtworkById(1);
			assertNotNull(retrievedArtwork);
			assertEquals(updatedArtwork.getTitle(), retrievedArtwork.getTitle());
			assertEquals(updatedArtwork.getMedium(), retrievedArtwork.getMedium());
	    }

	 @Test
	    public void testRemoveArtwork() throws ArtWorkNotFoundException {
	        // Add a sample artwork for testing
			Artwork artwork = new Artwork(1, "Test Title", "Test Description",
			        "2022-01-21", "Oil Painting", "test_image_url");
			virtualArtGallery.addArtwork(artwork);

			// Call the removeArtwork method
			boolean isRemoved = virtualArtGallery.removeArtwork(1);

			// Check if the artwork was removed successfully
			assertTrue(isRemoved);

			virtualArtGallery.getArtworkById(1);
			fail("ArtworkNotFoundException should have been thrown.");
	    }

	 @Test
	    public void testSearchArtworks() throws ArtWorkNotFoundException {
	        // Add sample artworks for testing
			Artwork artwork1 = new Artwork(1, "Landscape Painting", "Beautiful scenery",
			        "2022-01-21", "Oil Painting", "landscape_image_url");
			Artwork artwork2 = new Artwork(2, "Abstract Art", "Colorful and vibrant",
			        "2022-01-22", "Acrylic Painting", "abstract_image_url");
			virtualArtGallery.addArtwork(artwork1);
			virtualArtGallery.addArtwork(artwork2);

			// Call the searchArtworks method
			String keyword = "Landscape";  // Search keyword
			List<Artwork> searchResults = virtualArtGallery.searchArtworks(keyword);

			// Check if the search results contain the expected artwork
			assertFalse(searchResults.isEmpty());
			assertEquals(1, searchResults.size());
			assertEquals(artwork1.getTitle(), searchResults.get(0).getTitle());
	    }

	    @Test
	    public void testAddGallery() throws GalleryNotFoundException {
	        // Create a sample Gallery object for testing
			Gallery gallery = new Gallery(1, "Test Gallery", "Gallery Description",
			        "Test Location", new Artist(), "10:00 AM - 6:00 PM");

			// Call the addGallery method
			boolean isAdded = virtualArtGallery.addGallery(gallery);

			// Check if the gallery was added successfully
			assertTrue(isAdded);

			// Optional: Check if the added gallery is present in the database
			Gallery retrievedGallery = virtualArtGallery.getGalleryById(1);
			assertNotNull(retrievedGallery);
			assertEquals(gallery.getName(), retrievedGallery.getName());
	    }

	    @Test
	    public void testUpdateGallery() throws GalleryNotFoundException {
	        // Add a sample gallery for testing
			Gallery originalGallery = new Gallery(1, "Original Gallery", "Original Gallery Description",
			        "Original Location", new Artist(), "9:00 AM - 5:00 PM");
			virtualArtGallery.addGallery(originalGallery);

			// Create an updated version of the gallery
			Gallery updatedGallery = new Gallery(1, "Updated Gallery", "Updated Gallery Description",
			        "Updated Location", new Artist(), "10:00 AM - 6:00 PM");

			// Call the updateGallery method
			boolean isUpdated = virtualArtGallery.updateGallery(updatedGallery);

			// Check if the gallery was updated successfully
			assertTrue(isUpdated);

			// Optional: Check if the updated gallery details match the database
			Gallery retrievedGallery = virtualArtGallery.getGalleryById(1);
			assertNotNull(retrievedGallery);
			assertEquals(updatedGallery.getName(), retrievedGallery.getName());
			assertEquals(updatedGallery.getLocation(), retrievedGallery.getLocation());
	    }

	    @Test
	    public void testRemoveGallery() throws GalleryNotFoundException {
	        // Add a sample gallery for testing
			Gallery gallery = new Gallery(1, "Test Gallery", "Gallery Description",
			        "Test Location", new Artist(), "10:00 AM - 6:00 PM");
			virtualArtGallery.addGallery(gallery);

			// Call the removeGallery method
			boolean isRemoved = virtualArtGallery.removeGallery(1);

			// Check if the gallery was removed successfully
			assertTrue(isRemoved);

			virtualArtGallery.getGalleryById(1);
			fail("GalleryNotFoundException should have been thrown.");
	    }

	    @Test
	    public void testGetGalleryById() throws GalleryNotFoundException {
	        // Add a sample gallery for testing
			Gallery gallery = new Gallery(1, "Test Gallery", "Gallery Description",
			        "Test Location", new Artist(), "10:00 AM - 6:00 PM");
			virtualArtGallery.addGallery(gallery);

			// Call the getGalleryById method
			Gallery retrievedGallery = virtualArtGallery.getGalleryById(1);

			// Check if the retrieved gallery matches the added gallery
			assertNotNull(retrievedGallery);
			assertEquals(gallery.getName(), retrievedGallery.getName());
			assertEquals(gallery.getDescription(), retrievedGallery.getDescription());
	    }
}
