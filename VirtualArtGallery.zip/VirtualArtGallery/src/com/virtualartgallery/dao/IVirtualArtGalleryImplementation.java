package com.virtualartgallery.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import  com.virtualartgallery.entity.Artist;
import  com.virtualartgallery.entity.Artwork;
import  com.virtualartgallery.entity.Gallery;
import  com.virtualartgallery.entity.User;
import com.virtualartgallery.exception.ArtWorkNotFoundException;
import com.virtualartgallery.exception.UserNotFoundException;
import com.virtualartgallery.util.DBConnUtil;

public class IVirtualArtGalleryImplementation implements IVirtualArtGallery {
	

    // Artwork Management

    @Override
    public boolean addArtwork(Artwork artwork) {
        try (Connection connection = DBConnUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO artworks (title, description, creationDate, medium, imageURL, artworkID) VALUES (?, ?, ?, ?, ?, ?)",
                     Statement.RETURN_GENERATED_KEYS)) {

            preparedStatement.setString(1, artwork.getTitle());
            preparedStatement.setInt(6, artwork.getArtworkID());
            preparedStatement.setString(4, artwork.getMedium());
            preparedStatement.setString(2, artwork.getDescription());
            preparedStatement.setString(3, artwork.getCreationDate());
            preparedStatement.setString(5, artwork.getImageURL());

            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows > 0) {
                ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    artwork.setArtworkID(generatedKeys.getInt(1));
                    return true;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as per your requirement
        }
        return false;
    }

    @Override
    public boolean updateArtwork(Artwork artwork) throws ArtWorkNotFoundException {
        try (Connection connection = DBConnUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "UPDATE artworks SET title = ?, imageURL = ?, description = ?, creationDate = ? WHERE artworkID = ?")) {

            preparedStatement.setString(1, artwork.getTitle());
            preparedStatement.setString(2, artwork.getImageURL());
            preparedStatement.setString(3, artwork.getDescription());
            preparedStatement.setString(4, artwork.getCreationDate());
            preparedStatement.setInt(5, artwork.getArtworkID());

            int affectedRows = preparedStatement.executeUpdate();
            if(affectedRows>0) {
                return affectedRows > 0;}
                else
                {
                	throw new ArtWorkNotFoundException("Artwork not found for this ID: ");
                }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as per your requirement
        }
        return false;
    }

    @Override
    public boolean removeArtwork(int artworkId) throws ArtWorkNotFoundException {
        try (Connection connection = DBConnUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM artworks WHERE artworkID = ?")) {

            preparedStatement.setInt(1, artworkId);

            int affectedRows = preparedStatement.executeUpdate();
            if(affectedRows>0) {
            return affectedRows > 0;}
            else
            {
            	throw new ArtWorkNotFoundException("Artwork not found for ID: " + artworkId);
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as per your requirement
        }
        return false;
    }

    @Override
    public Artwork getArtworkById(int artworkId) throws ArtWorkNotFoundException {
    	Artwork artwork = new Artwork();
        try (Connection connection = DBConnUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM artworks WHERE artworkID = ?")) {

            preparedStatement.setInt(1, artworkId);

            try {
            	ResultSet resultSet = preparedStatement.executeQuery();
            	if (resultSet.next()) {
            	
                artwork.setArtworkID(resultSet.getInt("artworkID"));
                artwork.setTitle(resultSet.getString("title"));
                artwork.setMedium(resultSet.getString("Medium"));
                artwork.setDescription(resultSet.getString("description"));
                artwork.setCreationDate(resultSet.getString("creationDate"));
                artwork.setImageURL(resultSet.getString("ImageURL"));
                return artwork;
            }
			else {
				throw new ArtWorkNotFoundException("Artwork not found for ID: " + artworkId);
			}

        }catch (SQLException e) {
            e.printStackTrace();
            
            return null;
        }
    } catch (SQLException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
		return null;
	}}

    @Override
    public List<Artwork> searchArtworks(String keyword)throws ArtWorkNotFoundException {
        List<Artwork> artworks = new ArrayList<>();

        try (Connection connection = DBConnUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT * FROM artworks WHERE title LIKE ? OR description LIKE ?")) {

            preparedStatement.setString(1, "%" + keyword + "%");
            preparedStatement.setString(2, "%" + keyword + "%");

            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                artworks.add(createArtworkFromResultSet(resultSet));
            }
            } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as per your requirement
        }

        return artworks;
    }

    // User Favorites

    @Override
    public boolean addArtworkToFavorite(int userId, int artworkId) {
        try (Connection connection = DBConnUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO user_favorite_artworks (userID, artworkID) VALUES (?, ?)")) {

            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, artworkId);

            int affectedRows = preparedStatement.executeUpdate();
            return affectedRows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as per your requirement
        }
        return false;
    }

    @Override
    public boolean removeArtworkFromFavorite(int userId, int artworkId)throws UserNotFoundException {
        try (Connection connection = DBConnUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "DELETE FROM user_favorite_artworks WHERE userID = ? AND artworkID = ?")) {

            preparedStatement.setInt(1, userId);
            preparedStatement.setInt(2, artworkId);

            int affectedRows = preparedStatement.executeUpdate();
           if(affectedRows > 0) {
            return affectedRows > 0;
           }
           else
           {
        	   throw new UserNotFoundException("User with ID " + userId + " not found.");
           }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as per your requirement
        }
        return false;
    }

    @Override
    public List<Artwork> getUserFavoriteArtworks(int userId) {
        List<Artwork> favoriteArtworks = new ArrayList<>();

        try (Connection connection = DBConnUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT a.* FROM artworks a " +
                             "JOIN user_favorite_artworks uf ON a.artworkID = uf.artworkID " +
                             "WHERE uf.userID = ?")) {

            preparedStatement.setInt(1, userId);

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                favoriteArtworks.add(createArtworkFromResultSet(resultSet));
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle the exception as per your requirement
        }

        return favoriteArtworks;
    }

    

        // Other methods for managing artists, galleries, and users

        @Override
        public boolean addArtist(Artist artist) {
            try (Connection connection = DBConnUtil.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(
                         "INSERT INTO artists (name, bio) VALUES (?, ?)")) {

                preparedStatement.setString(1, artist.getName());
                preparedStatement.setString(2, artist.getBiography());

                int affectedRows = preparedStatement.executeUpdate();
                return affectedRows > 0;

            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception as per your requirement
            }
            return false;
        }

        @Override
        public boolean updateArtist(Artist artist) {
            try (Connection connection = DBConnUtil.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(
                         "UPDATE artists SET name = ?, bio = ? WHERE artistID = ?")) {

                preparedStatement.setString(1, artist.getName());
                preparedStatement.setString(2, artist.getBiography());
                preparedStatement.setInt(3, artist.getArtistID());

                int affectedRows = preparedStatement.executeUpdate();
                return affectedRows > 0;

            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception as per your requirement
            }
            return false;
        }

        @Override
        public boolean removeArtist(int artistId) {
            try (Connection connection = DBConnUtil.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM artists WHERE artistID = ?")) {

                preparedStatement.setInt(1, artistId);

                int affectedRows = preparedStatement.executeUpdate();
                return affectedRows > 0;

            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception as per your requirement
            }
            return false;
        }

        @Override
        public Artist getArtistById(int artistId) {
            try (Connection connection = DBConnUtil.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM artists WHERE artistID = ?")) {

                preparedStatement.setInt(1, artistId);

                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    return createArtistFromResultSet(resultSet);
                }

            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception as per your requirement
            }
            return null;
        }

        @Override
        public boolean addGallery(Gallery gallery) {
            try (Connection connection = DBConnUtil.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(
                         "INSERT INTO galleries (name, location) VALUES (?, ?)")) {

                preparedStatement.setString(1, gallery.getName());
                preparedStatement.setString(2, gallery.getLocation());

                int affectedRows = preparedStatement.executeUpdate();
                return affectedRows > 0;

            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception as per your requirement
            }
            return false;
        }

        @Override
        public boolean updateGallery(Gallery gallery) {
            try (Connection connection = DBConnUtil.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(
                         "UPDATE galleries SET name = ?, location = ? WHERE galleryID = ?")) {

                preparedStatement.setString(1, gallery.getName());
                preparedStatement.setString(2, gallery.getLocation());
                preparedStatement.setInt(3, Gallery.getGalleryID());

                int affectedRows = preparedStatement.executeUpdate();
                return affectedRows > 0;

            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception as per your requirement
            }
            return false;
        }

        @Override
        public boolean removeGallery(int galleryId) {
            try (Connection connection = DBConnUtil.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM galleries WHERE gallery_id = ?")) {

                preparedStatement.setInt(1, galleryId);

                int affectedRows = preparedStatement.executeUpdate();
                return affectedRows > 0;

            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception as per your requirement
            }
            return false;
        }

        @Override
        public Gallery getGalleryById(int galleryId) {
            try (Connection connection = DBConnUtil.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM galleries WHERE galleryID = ?")) {

                preparedStatement.setInt(1, galleryId);

                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    return createGalleryFromResultSet(resultSet);
                }

            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception as per your requirement
            }
            return null;
        }

        @Override
        public boolean addUser(User user) {
            try (Connection connection = DBConnUtil.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(
                         "INSERT INTO users (username, email, password) VALUES (?, ?, ?)")) {

                preparedStatement.setString(1, user.getUsername());
                preparedStatement.setString(2, user.getEmail());
                preparedStatement.setString(3, user.getPassword());

                int affectedRows = preparedStatement.executeUpdate();
                return affectedRows > 0;

            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception as per your requirement
            }
            return false;
        }

        @Override
        public boolean updateUser(User user) {
            try (Connection connection = DBConnUtil.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement(
                         "UPDATE users SET username = ?, email = ?, password = ? WHERE userID = ?")) {

                preparedStatement.setString(1, user.getUsername());
                preparedStatement.setString(2, user.getEmail());
                preparedStatement.setString(3, user.getPassword());
                preparedStatement.setInt(4, user.getUserID());

                int affectedRows = preparedStatement.executeUpdate();
                return affectedRows > 0;

            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception as per your requirement
            }
            return false;
        }

        @Override
        public boolean removeUser(int userId) {
            try (Connection connection = DBConnUtil.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM users WHERE userID = ?")) {

                preparedStatement.setInt(1, userId);

                int affectedRows = preparedStatement.executeUpdate();
                return affectedRows > 0;

            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception as per your requirement
            }
            return false;
        }

        @Override
        public User getUserById(int userId) {
            try (Connection connection = DBConnUtil.getConnection();
                 PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM users WHERE userID = ?")) {

                preparedStatement.setInt(1, userId);

                ResultSet resultSet = preparedStatement.executeQuery();

                if (resultSet.next()) {
                    return createUserFromResultSet(resultSet);
                }

            } catch (SQLException e) {
                e.printStackTrace();
                // Handle the exception as per your requirement
            }
            return null;
        }

        // Helper method to create an Artist object from a ResultSet
        private Artist createArtistFromResultSet(ResultSet resultSet) throws SQLException {
            Artist artist = new Artist();
            artist.setArtistID(resultSet.getInt("artistID"));
            artist.setName(resultSet.getString("name"));
            artist.setBiography(resultSet.getString("bio"));
            return artist;
        }

        // Helper method to create a Gallery object from a ResultSet
        private Gallery createGalleryFromResultSet(ResultSet resultSet) throws SQLException {
            Gallery gallery = new Gallery();
            gallery.setGalleryID(resultSet.getInt("galleryID"));
            gallery.setName(resultSet.getString("name"));
            gallery.setLocation(resultSet.getString("location"));
            return gallery;
        }

        // Helper method to create a User object from a ResultSet
        private User createUserFromResultSet(ResultSet resultSet) throws SQLException {
            User user = new User();
            user.setUserID(resultSet.getInt("userID"));
            user.setUsername(resultSet.getString("username"));
            user.setEmail(resultSet.getString("email"));
            user.setPassword(resultSet.getString("password"));
            return user;
        }
    
        // Helper method to create an Artwork object from a ResultSet
        private Artwork createArtworkFromResultSet(ResultSet resultSet) throws SQLException {
            Artwork artwork = new Artwork();
            artwork.setArtworkID(resultSet.getInt("artworkID"));
            artwork.setTitle(resultSet.getString("title"));
            artwork.setMedium(resultSet.getString("Medium"));
            artwork.setDescription(resultSet.getString("description"));
            artwork.setCreationDate(resultSet.getString("creationDate"));
            artwork.setImageURL(resultSet.getString("ImageURL"));
            return artwork;
        }
      
      
      }



