package com.virtualartgallery.entity;

public class ArtworkGallery {

    public int getArtworkID() {
		return artworkID;
	}
	public void setArtworkID(int artworkID) {
		this.artworkID = artworkID;
	}
	public int getGalleryID() {
		return galleryID;
	}
	public void setGalleryID(int galleryID) {
		this.galleryID = galleryID;
	}
	private int artworkID;
    private int galleryID;
	public ArtworkGallery(int artworkID, int galleryID) {
		super();
		this.artworkID = artworkID;
		this.galleryID = galleryID;
	}

}
