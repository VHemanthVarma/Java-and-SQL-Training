package com.virtualartgallery.entity;
public class Gallery {
    private static int galleryID;
    private String name;
    private String description;
    private String location;
    private Artist curator; // One-to-Many relationship
    private String openingHours;

    public Gallery(int galleryID, String name, String description, String location, String openingHours) {
		super();
		Gallery.galleryID = galleryID;
		this.name = name;
		this.description = description;
		this.location = location;
		this.openingHours = openingHours;
	}

	public Gallery(int galleryID, String name, String description, String location, Artist curator,
			String openingHours) {
		super();
		Gallery.galleryID = galleryID;
		this.name = name;
		this.description = description;
		this.location = location;
		this.curator = curator;
		this.openingHours = openingHours;
	}

	public static int getGalleryID() {
		return galleryID;
	}

	public void setGalleryID(int galleryID) {
		Gallery.galleryID = galleryID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Artist getCurator() {
		return curator;
	}

	public void setCurator(Artist curator) {
		this.curator = curator;
	}

	public String getOpeningHours() {
		return openingHours;
	}

	public void setOpeningHours(String openingHours) {
		this.openingHours = openingHours;
	}

	public Gallery() {
		super();
	}

	

	
}

