package com.virtualartgallery.entity;

public class UserFavoriteArtwork {
    private int userID;
    private int artworkID;
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public int getArtworkID() {
		return artworkID;
	}
	public void setArtworkID(int artworkID) {
		this.artworkID = artworkID;
	}
	public UserFavoriteArtwork(int userID, int artworkID) {
		super();
		this.userID = userID;
		this.artworkID = artworkID;
	}

}
