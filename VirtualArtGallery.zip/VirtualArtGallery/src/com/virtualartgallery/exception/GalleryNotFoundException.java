package com.virtualartgallery.exception;

@SuppressWarnings("serial")
public class GalleryNotFoundException extends Exception {

	public GalleryNotFoundException(String message) {
        super(message);
    }
}
